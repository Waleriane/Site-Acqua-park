/* =========================================================================
   DESCIDA NO TOBOGÃ — animação controlada pela rolagem
   -------------------------------------------------------------------------
   COMPUTADOR: quadros em imagem nítida (assets/descida/pc/001.webp ...).
     As imagens ficam guardadas "compactadas" e só o quadro da vez é aberto,
     por isso fica nítido E leve na memória.
   CELULAR: vídeo controlado pela rolagem (assets/video/descida-celular.mp4).

   ✏️ PARA TROCAR A DESCIDA (com ffmpeg):
     computador (quadros):
       ffmpeg -i novo-horizontal.mp4 -vf fps=20 -c:v libwebp -quality 72 assets/descida/pc/%03d.webp
       depois atualize QUADROS_PC abaixo com a quantidade de arquivos gerados
     celular (vídeo):
       ffmpeg -i novo-vertical.mp4 -an -c:v libx264 -crf 20 -g 1 -pix_fmt yuv420p -movflags +faststart assets/video/descida-celular.mp4

   ✏️ PARA MUDAR A DURAÇÃO DA ROLAGEM: altere --ride-length no css/style.css (seção 14)
   ✏️ PARA MUDAR QUANDO CADA TEXTO APARECE: altere data-from / data-to no index.html
   ========================================================================= */
(function () {
  'use strict';

  var RIDE = {
    PASTA_PC: 'assets/descida/pc/',
    QUADROS_PC: 160,
    VIDEO_CELULAR: 'assets/video/descida-celular.mp4',
    SUAVE: 0.14,      // ✏️ 0.08 = bem macio · 0.25 = mais direto
    FIM: 0.9          // a descida termina em 90% da rolagem; o resto segura a cena final
  };

  var section = document.querySelector('[data-ride]');
  if (!section) return;

  var video = section.querySelector('.ride__video');
  var canvas = section.querySelector('.ride__canvas');
  var ctx = canvas.getContext('2d');
  var loader = section.querySelector('.ride__loader');
  var bar = section.querySelector('.ride__progress span');
  var steps = Array.prototype.slice.call(section.querySelectorAll('[data-from]'));
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function isVertical() { return window.innerHeight > window.innerWidth; }
  var mode = '';            // 'pc' ou 'cel'
  var started = false;
  var shown = 0;
  var running = false;

  /* ---------------- COMPUTADOR: quadros ---------------- */
  var blobs = [];           // imagens guardadas compactadas
  var loadedCount = 0;
  var drawnIndex = -1;
  var decoding = false;
  var pendingIndex = -1;
  var useBitmap = 'createImageBitmap' in window;

  function frameUrl(i) { return RIDE.PASTA_PC + String(i + 1).padStart(3, '0') + '.webp'; }

  function loadFrames() {
    blobs = new Array(RIDE.QUADROS_PC);
    loadedCount = 0;
    // ordem: primeiro quadros espalhados (a descida já funciona), depois o resto
    var order = [], seen = {};
    [16, 8, 4, 2, 1].forEach(function (step) {
      for (var i = 0; i < RIDE.QUADROS_PC; i += step) if (!seen[i]) { seen[i] = 1; order.push(i); }
    });
    var idx = 0, active = 0, MAX = 6;
    function next() {
      while (active < MAX && idx < order.length) {
        (function (n) {
          active++;
          var p = (useBitmap && window.fetch && location.protocol !== 'file:')
            ? fetch(frameUrl(n)).then(function (r) { return r.blob(); })
            : new Promise(function (ok, no) { var im = new Image(); im.onload = function () { ok(im); }; im.onerror = no; im.src = frameUrl(n); });
          p.then(function (b) {
            blobs[n] = b; loadedCount++;
            loader.style.setProperty('--l', (loadedCount / RIDE.QUADROS_PC).toFixed(3));
            if (loadedCount >= RIDE.QUADROS_PC) loader.hidden = true;
            if (loadedCount === 1) section.classList.add('is-ready');
            drawnIndex = -1; tick();
          }).catch(function () {}).then(function () { active--; next(); });
        })(order[idx++]);
      }
    }
    next();
  }

  function sizeCanvas() {
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var r = canvas.getBoundingClientRect();
    canvas.width = Math.round(r.width * dpr);
    canvas.height = Math.round(r.height * dpr);
    ctx.imageSmoothingQuality = 'high';
    drawnIndex = -1;
  }

  function cover(img, w, h) {
    var iw = img.width || img.naturalWidth, ih = img.height || img.naturalHeight;
    var s = Math.max(w / iw, h / ih), dw = iw * s, dh = ih * s;
    ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
  }

  function nearestLoaded(i) {
    if (blobs[i]) return i;
    for (var d = 1; d < RIDE.QUADROS_PC; d++) {
      if (blobs[i - d]) return i - d;
      if (blobs[i + d]) return i + d;
    }
    return -1;
  }

  function showFrame(i) {
    var n = nearestLoaded(i);
    if (n < 0 || n === drawnIndex) return;
    if (decoding) { pendingIndex = n; return; }
    var item = blobs[n];
    if (!(item instanceof Blob)) { cover(item, canvas.width, canvas.height); drawnIndex = n; return; }
    decoding = true;
    createImageBitmap(item).then(function (bmp) {
      cover(bmp, canvas.width, canvas.height);
      if (bmp.close) bmp.close();          // libera a memória na hora
      drawnIndex = n;
    }).catch(function () {}).then(function () {
      decoding = false;
      if (pendingIndex >= 0 && pendingIndex !== drawnIndex) { var p = pendingIndex; pendingIndex = -1; showFrame(p); }
    });
  }

  /* ---------------- CELULAR: vídeo ---------------- */
  var duration = 0;
  function loadVideo() {
    duration = 0;
    var src = RIDE.VIDEO_CELULAR;
    function useUrl(url) { video.src = url; video.load(); }
    if (window.fetch && location.protocol !== 'file:') {
      fetch(src).then(function (res) {
        if (!res.ok || !res.body || !window.ReadableStream) return res.blob();
        var total = +res.headers.get('Content-Length') || 0, got = 0, chunks = [];
        var reader = res.body.getReader();
        function pump() {
          return reader.read().then(function (r) {
            if (r.done) return new Blob(chunks, { type: 'video/mp4' });
            chunks.push(r.value); got += r.value.length;
            if (total) loader.style.setProperty('--l', (got / total).toFixed(3));
            return pump();
          });
        }
        return pump();
      }).then(function (blob) { if (mode === 'cel') useUrl(URL.createObjectURL(blob)); })
        .catch(function () { useUrl(src); });
    } else { video.preload = 'auto'; useUrl(src); }
  }
  video.addEventListener('loadedmetadata', function () {
    duration = video.duration || 0;
    section.classList.add('is-ready');
    loader.hidden = true;
    var p = video.play();
    if (p && p.then) p.then(function () { video.pause(); tick(); }).catch(function () { tick(); });
    else { video.pause(); tick(); }
  });
  function seek(pos) {
    if (!duration) return;
    var t = Math.min(1, pos / RIDE.FIM) * (duration - 0.05);
    if (Math.abs(video.currentTime - t) > 0.02 && !video.seeking) video.currentTime = t;
  }

  /* ---------------- comum ---------------- */
  function setMode() {
    var m = isVertical() ? 'cel' : 'pc';
    if (m === mode) return;
    mode = m;
    section.classList.toggle('is-pc', m === 'pc');
    loader.hidden = false; loader.style.setProperty('--l', 0);
    if (m === 'pc') { sizeCanvas(); if (!blobs.length) loadFrames(); else { loader.hidden = true; } }
    else loadVideo();
  }

  function progress() {
    var rect = section.getBoundingClientRect();
    var total = section.offsetHeight - window.innerHeight;
    if (total <= 0) return 1;
    return Math.min(1, Math.max(0, -rect.top / total));
  }

  function updateUI(p) {
    section.style.setProperty('--p', p.toFixed(4));
    if (bar) bar.style.transform = 'scaleY(' + p.toFixed(4) + ')';
    steps.forEach(function (el) {
      var from = parseFloat(el.getAttribute('data-from'));
      var to = el.hasAttribute('data-to') ? parseFloat(el.getAttribute('data-to')) : 2;
      el.classList.toggle('is-on', p >= from && p <= to);
    });
    section.classList.toggle('is-end', p >= 0.88);
  }

  function loop() {
    var target = reduce ? 1 : progress();
    shown += (target - shown) * RIDE.SUAVE;
    if (Math.abs(target - shown) < 0.0005) shown = target;
    updateUI(target);
    if (mode === 'pc') showFrame(Math.round(Math.min(1, shown / RIDE.FIM) * (RIDE.QUADROS_PC - 1)));
    else seek(shown);
    if (shown !== target || (mode === 'cel' && video.seeking) || decoding) requestAnimationFrame(loop);
    else running = false;
  }

  function tick() {
    if (running) return;
    running = true;
    requestAnimationFrame(loop);
  }

  function onScroll() {
    var r = section.getBoundingClientRect();
    if (r.bottom < -100 || r.top > window.innerHeight + 100) return;
    tick();
  }

  function start() {
    if (started) return;
    started = true;
    setMode();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  var lastW = window.innerWidth, lastH = window.innerHeight;
  window.addEventListener('resize', function () {
    if (!started) return;
    var w = window.innerWidth, h = window.innerHeight;
    if (w === lastW && Math.abs(h - lastH) < 160) return;   // barra do celular aparecendo/sumindo
    lastW = w; lastH = h;
    setMode();
    if (mode === 'pc') { sizeCanvas(); tick(); }
  });

  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (en) {
      if (en[0].isIntersecting) { start(); io.disconnect(); }
    }, { rootMargin: '300% 0px' });
    io.observe(section);
  } else {
    window.addEventListener('load', start);
  }

  updateUI(reduce ? 1 : 0);
  if (reduce) section.classList.add('is-reduced');
})();
